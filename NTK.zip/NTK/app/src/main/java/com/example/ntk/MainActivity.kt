package com.example.ntk

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileWriter
import java.net.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var btnPing: Button
    private lateinit var btnTelnet: Button
    private lateinit var btnTracert: Button
    private lateinit var btnWifiTest: Button
    private lateinit var btnRunAll: Button
    private lateinit var btnSaveLogs: Button
    private lateinit var btnCopyLogs: Button
    private lateinit var btnOpenVivonow: Button
    private lateinit var tvResults: TextView
    private lateinit var tvNetworkInfo: TextView
    private lateinit var scrollView: ScrollView

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val logBuilder = StringBuilder()

    private val LOCATION_PERMISSION_REQUEST = 1
    private val STORAGE_PERMISSION_REQUEST = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        checkPermissions()
        loadNetworkInfo()
        setupClickListeners()
    }

    private fun initViews() {
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        btnPing = findViewById(R.id.btnPing)
        btnTelnet = findViewById(R.id.btnTelnet)
        btnTracert = findViewById(R.id.btnTracert)
        btnWifiTest = findViewById(R.id.btnWifiTest)
        btnRunAll = findViewById(R.id.btnRunAll)
        btnSaveLogs = findViewById(R.id.btnSaveLogs)
        btnCopyLogs = findViewById(R.id.btnCopyLogs)
        btnOpenVivonow = findViewById(R.id.btnOpenVivonow)
        tvResults = findViewById(R.id.tvResults)
        tvNetworkInfo = findViewById(R.id.tvNetworkInfo)
        scrollView = findViewById(R.id.scrollView)
    }

    private fun checkPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), LOCATION_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permissões concedidas!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Algumas funcionalidades podem estar limitadas.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadNetworkInfo() {
        scope.launch {
            val networkInfo = withContext(Dispatchers.IO) { getNetworkInfo() }
            tvNetworkInfo.text = networkInfo
        }
    }

    private fun getNetworkInfo(): String {
        return try {
            val sb = StringBuilder()
            val socket = Socket()
            socket.connect(InetSocketAddress("8.8.8.8", 80))
            val localIP = socket.localAddress.hostAddress
            socket.close()
            sb.append("IP Local: $localIP\n")
            sb.append("MAC Wi-Fi: ${getWifiMacAddress()}\n")
            sb.toString()
        } catch (e: Exception) {
            "Erro ao obter informações de rede: ${e.message}"
        }
    }

    private fun getWifiMacAddress(): String {
        return try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            var mac = wifiManager.connectionInfo.macAddress
            if (mac == null || mac == "02:00:00:00:00:00") {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                for (ni in Collections.list(interfaces)) {
                    if (ni.name.equals("wlan0", true)) {
                        val hardwareAddress = ni.hardwareAddress
                        if (hardwareAddress != null) {
                            mac = hardwareAddress.joinToString(":") { String.format("%02X", it) }
                            break
                        }
                    }
                }
            }
            mac ?: "Desconhecido"
        } catch (e: Exception) {
            "Erro: ${e.message}"
        }
    }

    private fun setupClickListeners() {

        btnPing.setOnClickListener {
            val host = etHost.text.toString().trim()
            if (host.isNotEmpty()) executePing(host)
            else appendResult("Por favor, digite um IP ou hostname")
        }

        btnTelnet.setOnClickListener {
            val host = etHost.text.toString().trim()
            val portStr = etPort.text.toString().trim()
            if (host.isNotEmpty() && portStr.isNotEmpty()) {
                try {
                    val port = portStr.toInt()
                    executeTelnet(host, port)
                } catch (e: NumberFormatException) {
                    appendResult("Porta inválida")
                }
            } else appendResult("Por favor, digite IP/hostname e porta")
        }

        btnTracert.setOnClickListener {
            val host = etHost.text.toString().trim()
            if (host.isNotEmpty()) executeTracert(host)
            else appendResult("Por favor, digite um IP ou hostname")
        }

        btnWifiTest.setOnClickListener { executeWifiTest() }
        btnRunAll.setOnClickListener { executeAllTests() }
        btnSaveLogs.setOnClickListener { saveLogs() }

        // copiar logs
        btnCopyLogs.setOnClickListener { copyLogsToClipboard() }
        // adicionar url para abeturura de chamado substiuir
        btnOpenVivonow.setOnClickListener {
            copyLogsToClipboard()
            val url = "google.com"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun copyLogsToClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("NetworkToolLogs", logBuilder.toString())
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "Logs copiados para a área de transferência", Toast.LENGTH_SHORT).show()
    }

    // -------------------- Métodos Ping, Telnet, Traceroute --------------------

    private fun executePing(host: String) {
        scope.launch {
            appendResult("=== PING para $host ===")
            try {
                val result = withContext(Dispatchers.IO) { performDetailedPing(host) }
                appendResult(result)
            } catch (e: Exception) {
                appendResult("Erro no ping: ${e.message}")
            }
            appendResult("========================\n")
        }
    }

    private fun performDetailedPing(host: String): String {
        val output = StringBuilder()
        try {
            val address = InetAddress.getByName(host)
            output.append("Host resolvido: ${address.hostAddress}\n")
            for (i in 1..4) {
                val start = System.currentTimeMillis()
                val reachable = address.isReachable(5000)
                val end = System.currentTimeMillis()
                val time = end - start
                if (reachable) appendResult("✓ Pacote $i: ${time}ms")
                else appendResult("✗ Pacote $i: Timeout")
                Thread.sleep(1000)
            }
        } catch (e: Exception) {
            output.append("Erro: ${e.message}")
        }
        return output.toString()
    }

    private fun executeTelnet(host: String, port: Int) {
        scope.launch {
            appendResult("=== TELNET para $host:$port ===")
            try {
                val result = withContext(Dispatchers.IO) { performTelnetTest(host, port) }
                appendResult(result)
            } catch (e: Exception) {
                appendResult("Erro no telnet: ${e.message}")
            }
            appendResult("===============================\n")
        }
    }

    private fun performTelnetTest(host: String, port: Int): String {
        val output = StringBuilder()
        try {
            val socket = Socket()
            val startTime = System.currentTimeMillis()
            socket.connect(InetSocketAddress(host, port), 5000)
            val endTime = System.currentTimeMillis()
            socket.close()
            output.append("Conexão bem-sucedida: ${endTime - startTime}ms\n")
        } catch (e: Exception) {
            output.append("Falha: ${e.message}\n")
        }
        return output.toString()
    }

    private fun executeTracert(host: String) {
        scope.launch {
            appendResult("=== TRACEROUTE para $host ===")
            try {
                val result = withContext(Dispatchers.IO) { performTraceroute(host) }
                appendResult(result)
            } catch (e: Exception) {
                appendResult("Erro no traceroute: ${e.message}")
            }
            appendResult("===============================\n")
        }
    }

    private fun performTraceroute(host: String): String {
        val output = StringBuilder()
        try {
            val addr = InetAddress.getByName(host)
            for (hop in 1..10) {
                val start = System.currentTimeMillis()
                val reachable = addr.isReachable(hop * 300)
                val end = System.currentTimeMillis()
                val time = end - start
                if (reachable) output.append("Hop $hop: ${time}ms\n")
                else output.append("Hop $hop: Timeout\n")
                if (reachable) break
                Thread.sleep(500)
            }
        } catch (e: Exception) {
            output.append("Erro: ${e.message}")
        }
        return output.toString()
    }

    // -------------------- Wi-Fi Scan com Barrinhas --------------------

    private fun executeWifiTest() {
        scope.launch {
            appendResult("=== TESTE DE SINAL Wi-Fi ===")
            try {
                val result = withContext(Dispatchers.IO) { getWifiInfoWithBars() }
                appendResult(result)
            } catch (e: Exception) {
                appendResult("Erro no teste Wi-Fi: ${e.message}")
            }
            appendResult("==============================\n")
        }
    }

    private fun getWifiInfoWithBars(): String {
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val sb = StringBuilder()
        if (!wifiManager.isWifiEnabled) return "Wi-Fi desabilitado"
        val wifiInfo = wifiManager.connectionInfo
        val rssi = wifiInfo.rssi
        val bars = WifiManager.calculateSignalLevel(rssi, 5) // 0 a 4
        val quality = when {
            rssi >= -50 -> "Excelente"
            rssi >= -60 -> "Muito Bom"
            rssi >= -70 -> "Bom"
            rssi >= -80 -> "Fraco"
            else -> "Muito Fraco"
        }
        sb.append("SSID: ${wifiInfo.ssid.replace("\"", "")}\n")
        sb.append("MAC: ${getWifiMacAddress()}\n")
        sb.append("RSSI: ${rssi} dBm\n")
        sb.append("Barras: ${"|".repeat(bars)} ($bars/4)\n")
        sb.append("Qualidade: $quality\n")
        return sb.toString()
    }

    // -------------------- Logs --------------------

    private fun appendResult(text: String) {
        runOnUiThread {
            val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val logEntry = "[$timestamp] $text"
            tvResults.append("$text\n")
            logBuilder.append("$logEntry\n")
            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun saveLogs() {
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { saveLogsToFile() }
                if (result) Toast.makeText(this@MainActivity, "Logs salvos com sucesso!", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this@MainActivity, "Erro ao salvar logs", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Erro: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveLogsToFile(): Boolean {
        return try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "NetworkToolKit_Log_$timestamp.txt"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            FileWriter(file).use { it.write(logBuilder.toString()) }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun executeAllTests() {
        scope.launch {
            val host = etHost.text.toString().ifEmpty { "8.8.8.8" }
            val port = etPort.text.toString().toIntOrNull() ?: 80
            executeWifiTest()
            delay(1000)
            executePing(host)
            delay(1000)
            executeTelnet(host, port)
            delay(1000)
            executeTracert(host)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
